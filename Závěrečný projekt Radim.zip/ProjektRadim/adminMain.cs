﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjektRadim
{
    public partial class adminMain : Form
    {
        public adminMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            userEdit userEdit = new userEdit();
            userEdit.FormClosed += (s, args) => this.Close();
            userEdit.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            contractEdit contractEdit = new contractEdit();
            contractEdit.FormClosed += (s, args) => this.Close();
            contractEdit.Show();
        }
    }
}
