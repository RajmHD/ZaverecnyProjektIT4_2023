﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjektRadim
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // připojení k databázi
            string connectionString = ("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=dbProject;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            // ověření uživatelského jména a hesla
            string username = textBox1.Text;
            string password = textBox2.Text;
            SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Name = @Name AND password = @Password", connection);
            command.Parameters.AddWithValue("@Name", username);
            command.Parameters.AddWithValue("@Password", password);
            int count = (int)command.ExecuteScalar();

            // získání role uživatele
            string role = "";
            if (count > 0)
            {
                command = new SqlCommand("SELECT role FROM users WHERE Name = @Name", connection);
                command.Parameters.AddWithValue("@Name", username);
                role = (string)command.ExecuteScalar();
            }

            // odkázání na další formulář podle role uživatele
            if (role.Equals("Admin"))
            {
                this.Hide();
                adminMain mainAdmin = new adminMain();
                mainAdmin.FormClosed += (s, args) => this.Close();
                mainAdmin.Show();
            }
            else if (role.Equals("User"))
            {
                this.Hide();
                userMain userMain = new userMain(username);
                userMain.FormClosed += (s, args) => this.Close();
                userMain.Owner = this;
                userMain.Show();
            }
            else
            {
                MessageBox.Show("Invalid username or password.");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
