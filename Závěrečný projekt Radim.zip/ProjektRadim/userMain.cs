﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjektRadim
{
    public partial class userMain : Form
    {
        private string username;
        private string connectionString;

        public userMain(string username)
        {
            InitializeComponent();
            this.username = username;
            label1.Text = this.username;
            connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=dbProject;Integrated Security=True";

        }
    }
}
